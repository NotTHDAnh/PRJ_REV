/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.model.registration;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.utils.DbUtils;

/**
 *
 * @author ADMIN
 */
public class RegistrationDAO implements Serializable {

    public boolean checkLogin(String username, String password)
            throws SQLException, ClassNotFoundException {

        boolean result = false; // user hoac password khong dung
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;

        try {
            //1. Model connects voi DB
            con = DbUtils.getConnection();

            if (con != null) {
                //2. Model se manipulates DB
                //2.1 Tao cau lenh SQL (tao sql string) -> cau lenh sql la cau lenh tinh
                String sql = "Select username "
                        + "From dbo.Registration "
                        + "Where username=? "
                        + "And password=?";
                //2.2 Tao ra statement object // statement cac cau lenh de thu thi code
                stm = con.prepareStatement(sql);
                stm.setString(1, username);
                stm.setString(2, password);
                //2.3 execute Query
                rs = stm.executeQuery();
                //3. xu li ket qua(bao gom : get du liet tu DB ve va xu li) 
                if (rs.next()) { // buoc 16 -> tra 1 dong vi username la duy nhat
                    result = true; // buoc 17 -> username va password da ton tai trong database
                }
            } // ham connection is availabe
        } finally {
            if (rs != null) {
                rs.close();
            }

            if (stm != null) {
                stm.close();
            }

            if (con != null) {
                con.close();
            }

        }
        return result;
    }

    private List<RegistrationDTO> accounts;

    public List<RegistrationDTO> getAccounts() {
        return accounts;
    } // go getAc ctrl space -> Enter

    public void searchLastname(String searchValue)
            throws SQLException, ClassNotFoundException {

        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;

        try {
            //1. Model connects voi DB
            con = DbUtils.getConnection();

            if (con != null) {
                //2. Model se manipulates DB
                //2.1 Tao cau lenh SQL (tao sql string) -> cau lenh sql la cau lenh tinh
                String sql = "Select username, password, lastname, isAdmin "
                        + "From dbo.Registration "
                        + "Where lastname like ?";
                //2.2 Tao ra statement object // statement cac cau lenh de thu thi code
                stm = con.prepareStatement(sql);
                stm.setString(1, "%" + searchValue + "%");
                //2.3 execute Query
                rs = stm.executeQuery();
                //3. xu li ket qua(bao gom : get du liet tu DB ve va xu li) 
                while (rs.next()) { // nhieu dong vi phu thuoc vao search value, 1 dong dung toan tu '='
                    // 3.1 model se get data tu resultset ( buoc so 16)
                    String username = rs.getString("username");
                    String password = rs.getString("password");
                    String fullName = rs.getString("lastname");
                    boolean role = rs.getBoolean("isAdmin");
                    //3.2 model se set data vao DTO object
                    RegistrationDTO dto = new RegistrationDTO(username, password, fullName, role);
                    if(this.accounts == null) {
                        this.accounts = new ArrayList<>();
                    }// account is unvaliable
                    this.accounts.add(dto);
                } // trverse moi hang(row) trong table 
            } // ham connection is availabe
        } finally {
            if (rs != null) {
                rs.close();
            }

            if (stm != null) {
                stm.close();
            }

            if (con != null) {
                con.close();
            }

        }

    }
}
