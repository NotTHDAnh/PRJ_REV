/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package pe.controllers;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pe.model.registration.RegistrationDAO;
import pe.model.registration.RegistrationDTO;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "SearchLastnameServlet", urlPatterns = {"/SearchLastnameServlet"})
public class SearchLastnameServlet extends HttpServlet { //k co the <servlet-class> trong the <servlet> vi co o day roi(class)

        private final String SEARCH_PATH = "search.html";
          private final String SEARCH_RESULT = "search.jsp";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String url = SEARCH_PATH;
        //1.Controller lay thong tin cua nguoi dung
        String searchValue = request.getParameter("txtSearchValue");
        try {

            if (searchValue.trim().length() > 0) {
                //2. controller call method cua model
                //2.1 ctl khoi tao DAO object
                RegistrationDAO dao = new RegistrationDAO();
                //2.2 ctl calls method cua DAO object (buoc 18)
                dao.searchLastname(searchValue);
                //3. ctl xu li ket qua
                List<RegistrationDTO> result = dao.getAccounts();
                request.setAttribute("SEARCH_SERVLET", result);
                url = SEARCH_RESULT;
                
//                if(result != null) { // found
//                    log("STT \t Username \t Password \t Fullname \t Role");
//                    int count = 0;
//                    
//                    for(RegistrationDTO dto : result){
//                        log(""
//                                + ++count
//                                + " \t "
//                                        + dto.getUsername()
//                                        + " \t "
//                                                + dto.getPassword()
//                                                + " \t "
//                                                        + dto.getFullName()
//                                                        + " \t "
//                                                                + dto.isRole());
//                                                                
//                    }//eachh dto in result list
//                }else { // not found
//                    log("No record is matched!!");
//                }

            } // searchig khi user nhap 1 gia tri hieu luc
        } catch (SQLException ex) {
            log("SearchLastnameServlet _ SQL " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            log("SearchLastnameServlet _ Class Not Found " + ex.getMessage());

        } finally {
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request,response);
            out.close();
        }

    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
