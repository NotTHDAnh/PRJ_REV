/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Computing Fundamental - HCM Campus
 */
public class DbUtils {
//    Do not change this code
    private static final String DB_NAME = "PRJ301";
    private static final String DB_USER_NAME = "sa"; //case-insensitive
    private static final String DB_PASSWORD = "12345";

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Connection conn = null; //Khai bao bien va gan null
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); //load driver
        
        //B2: Make connection string
        String url = "jdbc:sqlserver://localhost:1433;databaseName=" + DB_NAME; //Here is JDBC url
        
        //B3: Open Connection
        conn = DriverManager.getConnection(url, DB_USER_NAME, DB_PASSWORD);//muon driver chay can co Driver Management
        //1. url ketnoi db, usernam, va toi password
        return conn;
    }
}
